#Data
objFileName = "C:\_PythonClass\Assignment06\ToDo.txt"
strChoice = ""
strMenu = "" # A menu of user options
strData = "" # a row of text data from the file
dicRow = {} # A row of data separated into elements of a dictionary {Task,Priority}
lstTable = [] # A dictionary that acts as a 'table' of rows


def OpenFile():
    objFile = open("ToDo.txt", "r")
    for line in objFile:
        strData = line.split(",")  # readline() reads a line of the data into 2 elements
        dicRow = {"Task": strData[0].strip(), "Priority": strData[1].strip()}
        lstTable.append(dicRow)
    print("******* The current items ToDo are: *******")
    for row in lstTable:
        print(row["Task"] + "(" + row["Priority"] + ")")
    print("*******************************************")
OpenFile()

def DisplayMenu():
    print(
        """
        Menu of Options
        1) Show current data
        2) Add a new item.
        3) Remove an existing item.
        4) Save Data to File
        5) Exit Program
        """
    )
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    return strChoice
choice = strChoice
DisplayMenu()


def ShowCurrentItems(strChoice = 1): #1
    text_file = open("ToDo.txt", "r")
    lines = text_file.readlines()
    print("******* The current items ToDo are: *******")
    for row in lstTable:
        print(row["Task"] + "(" + row["Priority"] + ")")
    print("*******************************************")
ShowCurrentItems()

def InsertNewItemToList(strChoice = 2): #2
    strTask = str(input("What is the task? - ")).strip()
    strPriority = str(input("What is the priority? [high|low] - ")).strip()
    dicRow = {"Task": strTask, "Priority": strPriority}
    lstTable.append(dicRow)
    print("\nCurrent Data in table:")
    for row in lstTable:
        print(row["Task"] + "(" + row["Priority"] + ")")
    return dicRow
InsertNewItemToList()

def DeleteItemFromList(strChoice = 3): #3
    strKeyToRemove = input("Which TASK would you like removed? - ")
    blnItemRemoved = False  # Creating a boolean Flag
    intRowNumber = 0
    while (intRowNumber < len(lstTable)):
        if (strKeyToRemove == str(
                list(dict(lstTable[intRowNumber]).values())[0])):  # the values function creates a list!
            del lstTable[intRowNumber]
            blnItemRemoved = True
        # end if
        intRowNumber += 1
    # end for loop
    if (blnItemRemoved == True):
        print("The task was removed.")
    else:
        print("I'm sorry, but I could not find that task.")
setDelete = DeleteItemFromList()
print(setDelete)
DeleteItemFromList()

def SaveToFile(strChoice = 4): #4
    print("******* The current items ToDo are: *******")
    for row in lstTable:
        print(row["Task"] + "(" + row["Priority"] + ")")
    print("*******************************************")
    if ("y" == str(input("Save this data to file? (y/n) - ")).strip().lower()):
        objFile = open(objFileName, "w")
        for dicRow in lstTable:
            objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
        objFile.close()
        input("Data saved to file! Press the [Enter] key to return to menu.")
    else:
        input("New data was NOT Saved, but previous data still exists! Press the [Enter] key to return to menu.")
SaveToFile()
#def ExitProgram():


"""def UserSelection(strChoice):
    if strChoice == 1:
        return ShowCurrentItems
        
    elif strChoice == 2:
        print(InsertNewItemToList(2))
        #return InsertNewItemToList
    elif strChoice == 3:
        print(setDelete)
        #return DeleteItemFromList
    elif strChoice ==4:
        print(SaveToFile(4))
        #return SaveToFile
    else:
        print("What now?")"""

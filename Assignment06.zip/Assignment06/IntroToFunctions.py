#-------------------------------------------------#
# Title: Working with Functions
# Dev:   Jschade
# Date:  November 26, 2018
# ChangeLog: (Who, When, What)
#   JSchade, 12/17/2018, Created starting template
#   Joanna Schade, Added code to complete Assignment 6
# http://www.tutorialspoint.com/python/python_functions.htm
#-------------------------------------------------#

#-- Data:Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)


objFileName = "C:\_PythonClass\Assignment06\ToDo.txt"
strChoice = ""
strMenu = "" # A menu of user options
strData = "" # a row of text data from the file
dicRow = {} # A row of data separated into elements of a dictionary {Task,Priority}
lstTable = [] # A dictionary that acts as a 'table' of rows

#-- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

class Process(object):
    #@staticmethod
    def OpenFile(self):
        self.objFile = open("C:\_PythonClass\Assignment06\ToDo.txt", "r")
        for line in self.objFile:
            strData = line.split(",")  # readline() reads a line of the data into 2 elements
            dicRow = {"Task": strData[0].strip(), "Priority": strData[1].strip()}
            lstTable.append(dicRow)
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")

fileOpen = Process()
print(fileOpen.OpenFile())


    # -- Presentation --#
class InputOutput(object):
    # Step 2
    # Display a menu of choices to the user
    # @staticmethod
    def DisplayMenu():
        print(
            """
            Menu of Options
            1) Show current data
            2) Add a new item.
            3) Remove an existing item.
            4) Save Data to File
            5) Exit Program
            """
        )
        strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
        #return strChoice
    #choice = strChoice
    DisplayMenu()

        # Step 3
        # Display all todo items to user
#@staticmethod
def ShowCurrentItems(strChoice = 1): #1
    text_file = open("C:\_PythonClass\Assignment06\ToDo.txt", "r")
    lines = text_file.readlines()
    print("******* The current items ToDo are: *******")
    for row in lstTable:
        print(row["Task"] + "(" + row["Priority"] + ")")
    print("*******************************************")
ShowCurrentItems()

    # Step 4
    # Add a new item to the list/Table
#@staticmethod
def InsertNewItemToList(strChoice = 2): #2
    strTask = str(input("What is the task? - ")).strip()
    strPriority = str(input("What is the priority? [high|low] - ")).strip()
    dicRow = {"Task": strTask, "Priority": strPriority}
    lstTable.append(dicRow)
    print("\nCurrent Data in table:")
    for row in lstTable:
        print(row["Task"] + "(" + row["Priority"] + ")")
    return dicRow
InsertNewItemToList()

    # Step 5
    # Remove a new item to the list/Table
#@staticmethod
def DeleteItemFromList(strChoice = 3): #3
    strKeyToRemove = input("Which TASK would you like removed? - ")
    blnItemRemoved = False  # Creating a boolean Flag
    intRowNumber = 0
    while (intRowNumber < len(lstTable)):
        if (strKeyToRemove == str(
                list(dict(lstTable[intRowNumber]).values())[0])):  # the values function creates a list!
            del lstTable[intRowNumber]
            blnItemRemoved = True
        # end if
        intRowNumber += 1
    # end for loop
    if (blnItemRemoved == True):
        print("The task was removed.")
    else:
        print("I'm sorry, but I could not find that task.")
setDelete = DeleteItemFromList()
print(setDelete)
DeleteItemFromList()

    # Step 6
    # Save tasks to the ToDo.txt file
#@staticmethod
def SaveToFile(strChoice = 4): #4
    print("******* The current items ToDo are: *******")
    for row in lstTable:
        print(row["Task"] + "(" + row["Priority"] + ")")
    print("*******************************************")
    if ("y" == str(input("Save this data to file? (y/n) - ")).strip().lower()):
        objFile = open(objFileName, "w")
        for dicRow in lstTable:
            objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
        objFile.close()
        input("Data saved to file! Press the [Enter] key to return to menu.")
    else:
        input("New data was NOT Saved, but previous data still exists! Press the [Enter] key to return to menu.")
SaveToFile()

# Step 7
    # Exit program


while(True):
    InputOutput.DisplayMenu()
    Process.strChoice = Process.choice()
    if (strChoice == "1"):
        InputOutput.ShowCurrentItems(lstTable)
        continue
    elif (strChoice == "2"):
        InputOutput.InsertNewItemToList(lstTable)
        continue
    elif (strChoice == "3"):
        InputOutput.DeleteItemFromList(lstTable)
        continue
    elif (strChoice == "4"):
        InputOutput.SaveToFile(lstTable)
        if("y" == Process.SaveToFile()):
            InputOutput.InsertNewItemToList()
        else:
            continue
    elif (strChoice == "5"):
        break